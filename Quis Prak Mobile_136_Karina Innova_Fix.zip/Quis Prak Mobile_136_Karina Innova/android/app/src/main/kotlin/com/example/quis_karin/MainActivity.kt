package com.example.quis_karin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
